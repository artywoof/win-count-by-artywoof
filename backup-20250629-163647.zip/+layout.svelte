<script>
  import "../app.css";
</script>

<div class="w-[490px] h-[805px] bg-[#040319] border-6 border-solid border-[#ff00cc] shadow-[0_0_16px_#ff00cc] rounded-[50px] overflow-visible mx-auto my-auto relative z-50">
  <slot />
</div>
